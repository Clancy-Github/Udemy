const btn = document.querySelector('button');
const playerChoice = document.querySelector('#move');
const player = document.querySelector('#dino1');
const cpu = document.querySelector('#dino2');
let game = false;
console.log(playerChoice);
while (game != true){
    const choice = score(playerChoice);



}

function button(x){
    playerChoice.addEventListener('click', (e) => {
        e.preventDefault();
            player.classList.add("apply-shake");
            cpu.classList.add("apply-shake");
    })
    
    input.addEventListener("animationend", (e) => {
        player.classList.remove("apply-shake");
        cpu.classList.remove("apply-shake");
    });
}

function cpuMove() {
    let num = Math.floor(Math.random() * 3);
    let cpuChoice = '';
    if (num === 0){
        cpuChoice = "Rock";
    } if (num === 1) {
        cpuChoice = "Paper";
    } else {
        cpuChoice = "Scissors";
    }
    
    return cpuMoveChoice;
}